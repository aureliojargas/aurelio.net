#
#  Markup_BabelAppDelegate.py
#  Markup_Babel
#

from Foundation import *
from AppKit import *

from PyObjCTools import NibClassBuilder

class Markup_BabelAppDelegate(NibClassBuilder.AutoBaseClass):
    pass
