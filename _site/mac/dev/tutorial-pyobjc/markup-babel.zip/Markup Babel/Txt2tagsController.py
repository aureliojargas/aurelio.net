#
#  Txt2tagsController.py
#  Markup Babel
#
# Feito por Aurelio Marinho Jargas (verde)
# Agosto, 2007
#
# Instrucoes em:
#   http://aurelio.net/mac/dev/
#

from Foundation import *
import objc

# Importa o modulo do txt2tags (http://txt2tags.sf.net/pt)
import txt2tags

# Exemplo de como criar sua propria classe ao inves de usar a AppDelegate
class Txt2tagsController (NSObject):

	# Definicao dos bindings
	src = objc.ivar(u"src")

	# Cada target (formato) do txt2tags tem um binding
	for target in txt2tags.TARGETS:
		exec('%s = objc.ivar(u"%s")' % (target, target))

	# Metodo chamados quando o campo eh editado
 	def setSrc_(self, value):
		self.src = value
		
		# Se tem conteudo, converte e popula todos os textos
		# Senao, limpa todos
		if value != None:
			for target in txt2tags.TARGETS:
				setattr(self, target, self.convert(target))
		else:
			for target in txt2tags.TARGETS:
				setattr(self, target, "")

	# Metodo que converte o texto para o formato passado (target)
	# Aqui eh txt2tags puro, fora o self.src nao tem nada de PyObjC
	#
	def convert(self, target):
	
		# Precisa converter para ISO, pois o txt2tags tem bug com Unicode
		txt = self.src.encode('iso8859-1').split('\n')

		# Prepara as configuracoes
		config = txt2tags.ConfigMaster()._get_defaults()
		config['outfile'] = txt2tags.MODULEOUT  # results as list
		config['target'] = target
		config['headers'] = 0
		
		# Converte o texto
		body, toc = txt2tags.convert(txt, config)
		body = txt2tags.finish_him(body, config)
		
		# Retorna como string Unicode
		return unicode('\n'.join(body), 'iso8859-1')
		