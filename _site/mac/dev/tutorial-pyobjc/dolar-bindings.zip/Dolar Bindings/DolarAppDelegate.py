#
#  DolarAppDelegate.py
#  Dolar
#
# Feito por Aurelio Marinho Jargas (verde)
# Agosto, 2007
#
# Instrucoes em:
#   http://aurelio.net/mac/dev/
#

from Foundation import *
from AppKit import *

from PyObjCTools import NibClassBuilder

# O modulo objc precisa ser importado
import objc

class DolarAppDelegate(NibClassBuilder.AutoBaseClass):

	# Definicao dos bindings
	cotacao = objc.ivar(u"cotacao")
	dolares = objc.ivar(u"dolares")
	reais = objc.ivar(u"reais")
	
	# Os metodos chamados quando o campo eh editado
	def setCotacao_(self, valor):
		self.cotacao = valor
		if self.dolares and self.cotacao:
			self.setDolares_(self.dolares)

	def setDolares_(self, valor):
		self.dolares = valor
		self.reais = (self.dolares or 0) * (self.cotacao or 0)

	def setReais_(self, valor):
		self.reais = valor
		self.dolares = (self.reais or 0) / (self.cotacao or 1)
		