#
#  DolarAppDelegate.py
#  Dolar
#
# Feito por Aurelio Marinho Jargas (verde)
# Agosto, 2007
#
# Instrucoes em:
#   http://aurelio.net/mac/dev/
#

from Foundation import *
from AppKit import *

from PyObjCTools import NibClassBuilder

class DolarAppDelegate(NibClassBuilder.AutoBaseClass):

	def converte_(self, sender):
		print "-- converte_()"
#		print self.cotacao
#		print self.cotacao.floatValue()
		cotacao = self.cotacao.floatValue()
		dolares = self.dolares.floatValue()
		reais = cotacao * dolares
#		print reais
		self.reais.setFloatValue_(reais)
		